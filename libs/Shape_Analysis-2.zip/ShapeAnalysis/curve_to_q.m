function [q,len] = curve_to_q(beta)

[n,T] = size(beta);
v=gradient(beta,1/(T-1));

len = sum(sqrt(sum(v.*v)))/T;
v = v/len;
q=zeros(n,T);
for i = 1:T
    L = sqrt(norm(v(:,i)));
    if L > 0.0001
        q(:,i) = v(:,i)/L;
    else
        q(:,i) = v(:,i)*0.0001;
    end
end

