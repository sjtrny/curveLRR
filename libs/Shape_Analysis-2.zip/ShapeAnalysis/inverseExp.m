function v = inverseExp(q1,q2,beta2)
% Calculate the inverse exponential to obtain a shooting vector from q1 to
% q2 in shape space of open curves

T=length(q1);
beta2=beta2-repmat(calculateCentroid(beta2),1,T);

% Find Optimal Rotation of q2
[q2,O]=Find_Rotation_and_Seed_q(q1,q2);
beta2=O*beta2;

% Find the optimal coorespondence
gam = DynamicProgrammingQ(q1,q2,0,1);
gamI = invertGamma(gam);
gamI = (gamI-gamI(1))/(gamI(end)-gamI(1));

% Apply optimal re-parameterization to beta
beta2 = Group_Action_by_Gamma_Coord(beta2,gamI);
q2 = curve_to_q(beta2);

% Find Optimal Rotation of q2
[q2,O2]=Find_Rotation_and_Seed_q(q1,q2);

% Compute v_i = exp_mu^-1(q_i*)
q1dotq2=InnerProd_Q(q1,q2);
if q1dotq2>1
    q1dotq2=1;
end
u=q2-q1dotq2*q1;
normu=sqrt(InnerProd_Q(u,u));
if normu>10^-4
    v=u*acos(q1dotq2)/normu;
else
    v=zeros(2,T);
end