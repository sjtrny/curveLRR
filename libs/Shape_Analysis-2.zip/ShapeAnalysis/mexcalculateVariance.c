#include "mex.h"
#include <math.h>
#include "destdCurve.c"

void mexFunction(int nlhs, mxArray **plhs, int nrhs, const mxArray **prhs) {
    double *beta, *variance;
    int n, T;
    
    /* Input information */
    beta = mxGetPr(prhs[0]);
    n = mxGetM(prhs[0]);
    T = mxGetN(prhs[0]);
    
    plhs[0] = mxCreateDoubleMatrix(n, n, mxREAL);
    variance = mxGetPr(plhs[0]);
    
    calculateVariance(n, T, beta, variance);
    }