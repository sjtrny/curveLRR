function K = computeKarcherCov(betamean,Data,str)
T=length(betamean);
N=length(Data);

% Compute Karcher covariance of uniformly sampled mean
betamean=ReSampleCurve(betamean,T);
mu=projectCurve(curve_to_q(betamean),str);
basis=findBasisNormal(mu,str);

for i=1:N
%     q=qarray{i};
    beta=Data{i};

    % Compute w_i = exp_mu^-1(q_i*)
%     w=inverseExp(mu,q,beta);
    w=inverseExp_Coord(betamean,beta);
    % Project to tangent space of manifold to obtain v_i
    if str=='O'
        v(:,:,i)=w;
    else
        v(:,:,i)=projectTangent(w,mu,basis,str);
    end
end
    
K=zeros(2*T);
for i=1:N
    w=v(:,:,i);
    w=[w(1,:) w(2,:)];
    K=K+w'*w;
end
K=K/(N-1);