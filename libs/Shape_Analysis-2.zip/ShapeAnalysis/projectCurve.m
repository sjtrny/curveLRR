function qProj = projectCurve(q,str)

plotstuff=0;
T=length(q);
tol=10^-5;
maxit=200;
iter=0;
delta=.5;

x=q_to_curve(q);
a=-calculateCentroid(x);

% Algorithm for projection onto affine curve space
[Psi1(iter+1),Psi2(iter+1),Psi3(iter+1),Psi4(iter+1)]=Psi(x,a,q); 
if str=='A'
    r=[Psi1(iter+1);Psi2(iter+1);Psi3(iter+1);Psi4(iter+1)];
elseif str=='C'
    r=[Psi3(iter+1);Psi4(iter+1)];
end
rnorm=zeros(1,maxit);
rnorm(1)=norm(r);
while (norm(r)>tol) && (iter<maxit)
    % Find analytical basis for normal space at q
    basis=findBasisNormal(q,str);
    
    % Calculate Jacobian
    J=calculateJ(basis,str);
    
    % Newton-Raphson step to update q
    y=J\(-r);
    if str=='A'
        dq=delta*(y(1)*basis{1}+y(2)*basis{2}+y(3)*basis{3}+y(4)*basis{4});
    elseif str=='C'
        dq=delta*(y(1)*basis{1}+y(2)*basis{2});
    end
    normdq=sqrt(InnerProd_Q(dq,dq));
    q=cos(normdq)*q+sin(normdq)*dq/normdq;
    q=q/sqrt(InnerProd_Q(q,q));
    
    % Update x and a from the new q. 
    beta_new=q_to_curve(q);
%     beta_new=ReSampleCurve(beta_new,T);
    x=beta_new;
    a=-calculateCentroid(x);
    beta_new=x+repmat(a,1,T);
    
    % Calculate new value of Psi
    [Psi1(iter+1),Psi2(iter+1),Psi3(iter+1),Psi4(iter+1)]=Psi(x,a,q);
    if str=='A'
        r=[Psi1(iter+1);Psi2(iter+1);Psi3(iter+1);Psi4(iter+1)];
    elseif str=='C'
        r=[Psi3(iter+1);Psi4(iter+1)];
    end
    rnorm(iter+1)=norm(r);
    
    iter=iter+1;
    
    % Plot evolution
    if plotstuff
        figure(10);
        plot(beta_new(1,:),beta_new(2,:)); axis equal off;
    end
%     calculateVariance(beta_new)
%     pause(.2);
end
rnorm=rnorm(1:iter-1);
if plotstuff
    figure; plot(rnorm)
end

qProj=q;