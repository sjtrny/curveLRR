function wbar = parallelTranslate(w,q1,q2,basis,str)

wtilde=w-2*InnerProd_Q(w,q2)/InnerProd_Q(q1+q2,q1+q2)*(q1+q2);
l=sqrt(InnerProd_Q(wtilde,wtilde));

if (str=='A') || (str=='C')
    
    wbar=projectTangent(wtilde,q2,basis,str);
    normwbar=sqrt(InnerProd_Q(wbar,wbar));
    if normwbar>10^-4
        wbar=wbar*l/normwbar;
    end
    
else
    
    wbar=wtilde;
    
end
