function [beta_scaled,scale] = scale_curve(beta)
% Scales curve to length 1

[n,T]=size(beta);
% del=zeros(1,T);
% for j=2:T
%     del(j)=norm(P(:,j)-P(:,j-1));
% end
% scale=sum(del);
% P_scaled=P/scale;
    %Xdata_scaled{i}(:,1)=Xdata_scaled{i}(:,1)+[.001;.001];
normbetadot=zeros(1,T);
betadot=gradient(beta,1/T);
for i=1:T
    normbetadot(i)=norm(betadot(:,i));
end
scale=trapz(linspace(0,1,T),normbetadot);
beta_scaled=beta/scale;
