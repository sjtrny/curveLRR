#include "mex.h"
#include <math.h>
#include "destdCurve.c"

void mexFunction(int nlhs, mxArray **plhs, int nrhs, const mxArray **prhs) {
    int n, T, N;
    double *X, *Xn;
    
    /* Get input information */
    X = mxGetPr(prhs[0]);
    n = mxGetM(prhs[0]);
    T = mxGetN(prhs[0]);
    N = (int) *mxGetPr(prhs[1]);
    
    /* Allocate storage for output */
    plhs[0] = mxCreateDoubleMatrix(n, N, mxREAL);
    Xn = mxGetPr(plhs[0]);
    
    ReSampleCurve(n, T, X, N, Xn);
    }