function variance = calculateVariance(beta)

[n,T]=size(beta);
betadot=gradient(beta,1/(T-1));
normbetadot=zeros(1,T);
c=calculateCentroid(beta);
integrand=zeros(n,n,T);
t=linspace(0,1,T);
for i=1:T
    normbetadot(i)=norm(betadot(:,i));
    integrand(:,:,i)=(beta(:,i)-c)*(beta(:,i)-c)'*normbetadot(i);
end
L=trapz(t,normbetadot);
variance=trapz(t,integrand,3);
variance=variance/L;