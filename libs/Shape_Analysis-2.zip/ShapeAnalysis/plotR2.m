function h = plotR2(beta,color)

if(nargin==1)
    h=plot(beta(1,:),beta(2,:),'LineWidth',3); axis equal off;
else
    h=plot(beta(1,:),beta(2,:),color,'LineWidth',3); axis equal off;
end;