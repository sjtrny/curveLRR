function [mu,betamean,v] = findKarcherMean(qarray,Xdata,str)
% Algorithm 24 on page 210 of manuscript. This algorithm computes the
% intrinsic Karcher mean. 
% str='O' : Shape space of open curves
% str='C' : Shape space of closed curves
% str='A' : Shape space of affine curves

plotstuff=1;
N=length(qarray);
T=length(qarray{1});

% Initialize mu as one of the shapes
shape=1;
mu=qarray{shape};
betamean=Xdata{shape};

delta=0.5;
tolv=10^-4;
told=5*10^-3;
maxit=20;
iter=1;
% E=[0 -1; 1 0]/sqrt(2);
sumd(1)=0;

% Compute the Karcher mean
while iter<=maxit
    
    if plotstuff
        figure(3); plotR2(betamean,'b'); 
        title(['Iteration: ' num2str(iter)]);
    end
    
    mu=mu/sqrt(InnerProd_Q(mu,mu));
    if str=='A' || str=='C'
        basis=findBasisNormal(mu,str);
    end
    
    sumv=zeros(2,T);
    sumd(iter+1)=0;
    for i=1:N
        q=qarray{i};
        beta=Xdata{i};

        % Compute shooting vector from mu to q_i
        [w,d]=inverseExp_Coord(betamean,beta);
        
        % Project to tangent space of manifold to obtain v_i
        if str=='O'
            v(:,:,i)=w;
        else
            %v(:,:,i)=projectTangent(w,q,basis,str);
            v(:,:,i)=projectTangent(w,mu,basis,str);
        end

        sumv=sumv+v(:,:,i);
        sumd(iter+1)=sumd(iter+1)+d^2;
    end
    
    % Compute average direction of tangent vectors v_i
    vbar=sumv/N;
    
%     % Subtract off the component in the direction of the rotation orbit
%     vbar=vbar-InnerProd_Q(vbar,E*mu)*E*mu;
    
    normvbar(iter)=sqrt(InnerProd_Q(vbar,vbar));
    normv=normvbar(iter);
    
    if (normv>tolv) && abs(sumd(iter+1)-sumd(iter))>told
        % Update mu in direction of vbar
        mu=cos(delta*normvbar(iter))*mu+sin(delta*normvbar(iter))*vbar/normvbar(iter);

        % Project the updated mean to the affine (or closed) shape manifold
        if str=='A' || str=='C'
            mu=projectCurve(mu,str);
        end
        
        x=q_to_curve(mu);
        a=-calculateCentroid(x);
        betamean=x+repmat(a,1,T); 
%         temp=x+repmat(a,1,T);
%         betamean=Find_Rotation_and_Seed_Coord(betamean,temp);
   
    else
        break
    end
    
    iter=iter+1;
end

if plotstuff
    figure; plot(sumd(2:end));
    figure; plot(normvbar);
    figure; plotR2(betamean,'b'); 
end

        
        
        