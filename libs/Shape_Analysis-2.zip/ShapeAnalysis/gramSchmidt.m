function basis_o = gramSchmidt(basis,str)

if strcmp(str,'C')
    
    b1=basis{1};
    b2=basis{2};
    
    basis1=b1/sqrt(InnerProd_Q(b1,b1));
    b2=b2-InnerProd_Q(basis1,b2)*basis1;
    basis2=b2/sqrt(InnerProd_Q(b2,b2));
  
    basis_o{1}=basis1;
    basis_o{2}=basis2;
    
elseif strcmp(str,'A')
    
    b1=basis{1};
    b2=basis{2};
    b3=basis{3};
    b4=basis{4};
    
    basis1=b1/sqrt(InnerProd_Q(b1,b1));
    b2=b2-InnerProd_Q(basis1,b2)*basis1;
    basis2=b2/sqrt(InnerProd_Q(b2,b2));
    b3=b3-InnerProd_Q(basis1,b3)*basis1-InnerProd_Q(basis2,b3)*basis2;
    basis3=b3/sqrt(InnerProd_Q(b3,b3));
    b4=b4-InnerProd_Q(basis1,b4)*basis1-InnerProd_Q(basis2,b4)*basis2-InnerProd_Q(basis3,b4)*basis3;
    basis4=b4/sqrt(InnerProd_Q(b4,b4));
    
    basis_o{1}=basis1;
    basis_o{2}=basis2;
    basis_o{3}=basis3;
    basis_o{4}=basis4;
    
end