function basis = findBasisNormal(q,str)
% Return basis vectors for normal space at q. basis is a cell array of size
% 2 if str=='C' and is of size 4 if str=='A'

[n,T]=size(q);

if strcmp(str,'C')
    
    f1=zeros(n,T);
    f2=zeros(n,T);
    for i=1:T
        f1(:,i)=q(1,i)*q(:,i)/norm(q(:,i))+[norm(q(:,i));0];
        f2(:,i)=q(2,i)*q(:,i)/norm(q(:,i))+[0;norm(q(:,i))];
    end
    h3=f1;
    h4=f2;
    integrandb3=zeros(1,T);
    integrandb4=zeros(1,T);
    for i=1:T
        integrandb3(i)=q(:,i)'*h3(:,i);
        integrandb4(i)=q(:,i)'*h4(:,i);
    end
    b3=h3-q*trapz(linspace(0,1,T),integrandb3);
    b4=h4-q*trapz(linspace(0,1,T),integrandb4);
    
    basis{1}=b3;
    basis{2}=b4;
    
elseif strcmp(str,'A')  
    
    x=q_to_curve(q);
    a=-calculateCentroid(x);
    f1=zeros(n,T);
    f2=zeros(n,T);
    integrandQ=zeros(1,T);
    integrandG1=zeros(1,T);
    integrandG2=zeros(1,T);
    for i=1:T
        f1(:,i)=q(1,i)*q(:,i)/norm(q(:,i))+[norm(q(:,i));0];
        f2(:,i)=q(2,i)*q(:,i)/norm(q(:,i))+[0;norm(q(:,i))];
        integrandQ(i)=q(:,i)'*q(:,i);
        integrandG1(i)=integrandQ(i)*x(1,i);
        integrandG2(i)=integrandQ(i)*x(2,i);
    end
    Q=cumsum(integrandQ)/T;
    G1=cumsum(integrandG1)/T;
    G2=cumsum(integrandG2)/T;

    h1=zeros(n,T);
    h2=zeros(n,T);
    h3=f1;
    h4=f2;
    integrandb1=zeros(1,T);
    integrandb2=zeros(1,T);
    integrandb3=zeros(1,T);
    integrandb4=zeros(1,T);
    for i=1:T
        h1(:,i)=2*(2*a(1)*q(:,i)*x(1,i)-2*a(2)*q(:,i)*x(2,i)+a(1)*f1(:,i)*(1-Q(i))-...
            a(2)*f2(:,i)*(1-Q(i))+q(:,i)*x(1,i)^2-q(:,i)*x(2,i)^2+...
            f1(:,i)*(a(1)-G1(i))-f2(:,i)*(a(2)-G2(i)));
        h2(:,i)=2*a(2)*q(:,i)*x(1,i)+2*a(1)*q(:,i)*x(2,i)+a(2)*f1(:,i)*(1-Q(i))+...
            a(1)*f2(:,i)*(1-Q(i))+2*q(:,i)*x(1,i)*x(2,i)+f1(:,i)*(a(2)-G2(i))+...
            f2(:,i)*(a(1)-G1(i));
        integrandb1(i)=q(:,i)'*h1(:,i);
        integrandb2(i)=q(:,i)'*h2(:,i);
        integrandb3(i)=q(:,i)'*h3(:,i);
        integrandb4(i)=q(:,i)'*h4(:,i);
    end
    b1=h1-q*trapz(linspace(0,1,T),integrandb1);
    b2=h2-q*trapz(linspace(0,1,T),integrandb2);
    b3=h3-q*trapz(linspace(0,1,T),integrandb3);
    b4=h4-q*trapz(linspace(0,1,T),integrandb4);
    
    basis{1}=b1;
    basis{2}=b2;
    basis{3}=b3;
    basis{4}=b4;
    
end