/* Matrix product operation (c = a*b) */
void
product(int m, int n, int nn, double *a, double *b, double *c) {
    /* a is [m x n]
     * b is [n x nn]
     * c is [m x nn] */
    int k, j, i;
    
    for (k=0; k<m; k++)
        for (j=0; j<nn; j++) {
            c[k+j*m] = 0; /* zero out c[k,j] */
            for (i=0; i<n; i++)
                c[k+j*m] += a[k+i*m]*b[i+j*n];
            }
    }


/* Inplace Matrix product operation (b = a*b)
 * 
 * Parameters:
 *   n  - row/column size of 'a'
 *   nn - number of columns in 'b'
 *   a  - pointer left matrix to multiply [n x n]
 *   b  - pointer to right matrix to multiply and return variable [n x nn]
 */
void
product_in(int n, int nn, double *a, double *b) {
    /* a is [n x n]
     * b is [n x nn]
     * c is [n x nn] */
    int k, j, i;
    double *v = mxMalloc(n*sizeof(double));
    
    for (j=0; j<nn; j++) {
        for (k=0; k<n; k++)
            v[k] = b[k+j*n];
        
        for (k=0; k<n; k++) {
            b[k+j*n] = 0; /* zero out c[k,j] */
            for (i=0; i<n; i++)
                b[k+j*n] += a[k+i*n]*v[i];
            }
        }
    
    mxFree(v);
    }


/* Matrix product operation but c is not zeroed. So, matrix product is 
 * added to c.*/
void
product_sum(int m, int n, int nn, double *a, double *b, double *c) {
    /* a is [m x n]
     * b is [n x nn]
     * c is [m x nn] */
    int k, j, i;
    
    for (k=0; k<m; k++)
        for (j=0; j<nn; j++) {
            for (i=0; i<n; i++)
                c[k+j*m] += a[k+i*m]*b[i+j*n];
            }
    }


/* Computes the inverse of a 3x3 matrix in place. */
void
inverse3_in(double *M) {
    /*   | a b c |    |ei-fh ch-bi bf-ce |
     * M=| d e f | MI=|fg-di ai-cg cd-af |*1/(a(ei-fh)-d(ch-bi)+g(bf-ce))
     *   | g h i |    |dh-eg bg-ah ae-bd |
     */
    
    double ei_fh = M[4]*M[8]-M[7]*M[5];
    double ch_bi = M[6]*M[5]-M[3]*M[8];
    double bf_ce = M[3]*M[7]-M[6]*M[4];
    double fg_di = M[7]*M[2]-M[1]*M[8];
    double ai_cg = M[0]*M[8]-M[6]*M[2];
    double cd_af = M[6]*M[1]-M[0]*M[7];
    double dh_eg = M[1]*M[5]-M[4]*M[2];
    double bg_ah = M[3]*M[2]-M[0]*M[5];
    double ae_bd = M[0]*M[4]-M[3]*M[1];
    double c = (M[0]*ei_fh + M[1]*ch_bi+M[2]*bf_ce);
    
    M[0] = ei_fh/c;
    M[1] = fg_di/c;
    M[2] = dh_eg/c;
    M[3] = ch_bi/c;
    M[4] = ai_cg/c;
    M[5] = bg_ah/c;
    M[6] = bf_ce/c;
    M[7] = cd_af/c;
    M[8] = ae_bd/c;
    }

void
spline_coef(double *x, double *y, int n, double *z) {
    int IX;
    double *h = malloc(sizeof(double)*(n-1));
    double *b = malloc(sizeof(double)*(n-1));
    double *u = malloc(sizeof(double)*(n));
    double *v = malloc(sizeof(double)*(n));

    for (IX=0; IX<n-1; IX++) {
        h[IX] = x[IX+1] - x[IX];
        b[IX] = (y[IX+1] - y[IX])/h[IX];
        }

    u[0] = 1;
    v[0] = 0;
    for (IX=1; IX<n-1; IX++) {
        u[IX] = 2*(h[IX] + h[IX-1]);
        v[IX] = 6*(b[IX] - b[IX-1]);
        }
    u[n-1] = 1;
    v[n-1] = 0;

    v[1] = v[1] - v[0]*(h[0]/u[0]);
    for (IX=2; IX<n-1; IX++) {
        u[IX] = u[IX] - (h[IX-1]/u[IX-1])*h[IX-1];
        v[IX] = v[IX] - (h[IX-1]/u[IX-1])*v[IX-1];
        }

    z[n-1] = v[n-1]/u[n-1];
    for (IX=n-2; IX>0; IX--)
        z[IX] = (v[IX] - v[IX+1]*h[IX]/u[IX+1])/u[IX];
    z[0] = v[0]/u[0];

    free(h); free(b); free(u); free(v);
    }


void
spline_eval(double *t, double *y, double *z, int n, double *x, 
            double *out, int nn) {
    int j,i;
    double tmp;
    double h;
    
    /* any points before t[0] are set to zero */
    j=0;
    while (x[j]<t[0])
        out[j++] = 0.0;
    
    /* check if the next point is t[0] */
    if (x[j]==t[0])
        out[j++] = y[0];
    
    /* for points between t[0] and t[n-1] we interpolate */
    i = 0;
    for (j; j<nn; j++) {
        while (x[j]>t[i] && i<=n-1)
            i++;
        i--;
        if (i<0)
            mexErrMsgTxt("Something bad happened (i<0).");
        else if (i>n-1) /* we should be done with interpolation now */
            break;
        
        if (x[j]==t[i+1]) { /* found known point */
            out[j] = y[i+1];
            continue;
            }
        
        /* spline interpolation */
        h = t[i+1]-t[i];
        tmp = (z[i]/2) + (x[j]-t[i])*(z[i+1]-z[i])/(6*h);
        tmp = -(h/6)*(z[i+1]+2*z[i]) + (y[i+1]-y[i])/h + (x[j]-t[i])*tmp;
        out[j] = y[i] + (x[j]-t[i])*tmp;
        }
    
    /* remaining points should be greater than t[n-1] so set to zero */
    for (j; j<nn; j++)
        out[j] = 0.0;
    }


/* Computes gradient in across columns of f. */
void
col_gradient(int nrows, int ncols, double *f, 
             double step, double *df) {
    int k, j;
    int colN = nrows*(ncols-1);
    int colN1 = nrows*(ncols-2);
    
    for (k=0; k<nrows; k++) { /* loop over rows of f */
        /* Take forward differences on left and right edges */
        df[k] = (f[k+nrows] - f[k])/step;
        df[k+colN] = (f[k+colN] - f[k+colN1])/step;
        
        /* Take centered differences on interior points */
        for (j=1; j<ncols-1; j++) {
            df[k+j*nrows] = (f[k+(j+1)*nrows]-f[k+(j-1)*nrows])/(2*step);
            }
        }
    }


/* Trapezoidal numerical integration. */
void
trapz(int nrows, int ncols, double *x, double *y, int dim, double *z) {
    int k, j;
    
    if (dim==2) { /* integrate across columns */
        for (k=0; k<nrows; k++) {
            z[k] = 0; /* zero out z */
            
            /* integrate */
            for (j=0; j<ncols-1; j++)
                z[k] += (x[j+1]-x[j]) * (y[k+nrows*(j+1)] + y[k+nrows*j]);
            z[k] *= 0.5;
            }
        }
    else { /* integrate across rows */
        for (j=0; j<ncols; j++) {
            z[j] = 0; /* zero out z */
            
            /* integrate */
            for (k=0; k<nrows-1; k++)
                z[j] += (x[k+1]-x[k]) * (y[k+1+nrows*j] + y[k+nrows*j]);
            z[j] *= 0.5;
            }
        }
    }


/* Trapezoidal numerical integration in third dimension. */
void
trapz3(int nr, int nc, int nd, double *x, double *y, double *z) {
    /* x is [1 x nd]
     * y is [nr x nc x nd]
     * z is [nr x nc] */
    int k, j, i, ij;
    int nrc = nr*nc;
    
    for (i=0; i<nr; i++)
        for (j=0; j<nc; j++) {
            ij = i+j*nr;
            z[ij] = 0;
            for (k=0; k<nd-1; k++)
                z[ij] += (x[k+1]-x[k])*(y[ij+(k+1)*nrc]+y[ij+k*nrc]);
            z[ij] *= 0.5;
            }
    }


void
calculateCentroid(int n, int T, double *beta, double *centroid) {
    int k, j;
    double step = 1.0/(double) T;
    double step2 = 1.0/((double) T - 1.0); /* maybe we don't need this */
    double scale;
    
    double *betadot = mxMalloc(n*T*sizeof(double)); /* n x T */
    double *integrand = mxMalloc(n*T*sizeof(double)); /* n x T */
    double *normbetadot = mxMalloc(T*sizeof(double)); /* 1 x T */
    double *time = mxMalloc(T*sizeof(double)); /* 1 x T */
    
    /* compute gradient */
    col_gradient(n, T, beta, step, betadot);
    
    /* compute norm of each column of betadot*/
    for (j=0; j<T; j++) {
        normbetadot[j] = 0;
        for (k=0; k<n; k++)
            normbetadot[j] += betadot[k+n*j]*betadot[k+n*j];
        normbetadot[j] = sqrt(normbetadot[j]);
        }
    
    /* normalize beta by norm of betadot */
    for (j=0; j<T; j++)
        for (k=0; k<n; k++)
            integrand[k+n*j] = beta[k+n*j]*normbetadot[j];
    
    /* form time vector */
    time[0] = 0;
    for (k=1; k<T; k++)
        time[k] = time[k-1]+step2;
    
    trapz(1, T, time, normbetadot, 2, &scale);
    trapz(n, T, time, integrand, 2, centroid);
    
    for (k=0; k<n; k++)
        centroid[k] /=scale;
    
    mxFree(betadot);
    mxFree(integrand);
    mxFree(normbetadot);
    mxFree(time);
    }


void
calculateVariance(int n, int T, double *beta, double *variance) {
    int k, j, i;
    double step = 1.0/(double) T;
    double step2 = 1.0/((double) T - 1.0); /* maybe we don't need this */
    double scale;
    
    double *betadot = mxMalloc(n*T*sizeof(double)); /* n x T */
    double *normbetadot = mxMalloc(T*sizeof(double)); /* 1 x T */
    double *integrand = mxMalloc(n*n*T*sizeof(double)); /* n x n x T */
    double *time = mxMalloc(T*sizeof(double)); /* 1 x T */
    
    /* compute gradient */
    col_gradient(n, T, beta, step, betadot);
    
    /* compute norm of each column of betadot*/
    for (j=0; j<T; j++) {
        normbetadot[j] = 0;
        for (k=0; k<n; k++)
            normbetadot[j] += betadot[k+n*j]*betadot[k+n*j];
        normbetadot[j] = sqrt(normbetadot[j]);
        }
    
    /* form time vector */
    time[0] = 0;
    for (k=1; k<T; k++)
        time[k] = time[k-1]+step2;
    trapz(1, T, time, normbetadot, 2, &scale);
    
    for (k=0; k<T; k++)
        for (j=0; j<n; j++)
            for (i=0; i<n; i++)
                integrand[j+n*i+n*n*k] = beta[j+n*k]*beta[i+n*k]*normbetadot[k];
    
    trapz3(n, n, T, time, integrand, variance);
    for (k=0; k<n*n; k++)
        variance[k] /= scale;
    
    mxFree(betadot);
    mxFree(integrand);
    mxFree(normbetadot);
    mxFree(time);
    }


/* Scales curve to length 1 */
void
scale_curve(int n, int T, double *beta, double *beta_scaled) {
    int k, j;
    double step = 1.0/(double) T;
    double step2 = 1.0/((double) T - 1.0); /* maybe we don't need this */
    double scale;
    
    double *betadot = mxMalloc(n*T*sizeof(double)); /* n x T */
    double *normbetadot = mxMalloc(T*sizeof(double)); /* 1 x T */
    double *time = mxMalloc(T*sizeof(double)); /* 1 x T */
    
    /* compute gradient */
    col_gradient(n, T, beta, step, betadot);
    
    /* compute norm of each column of betadot*/
    for (j=0; j<T; j++) {
        normbetadot[j] = 0;
        for (k=0; k<n; k++)
            normbetadot[j] += betadot[k+n*j]*betadot[k+n*j];
        normbetadot[j] = sqrt(normbetadot[j]);
        }
    
    /* form time vector */
    time[0] = 0;
    for (k=1; k<T; k++)
        time[k] = time[k-1]+step2;
    
    trapz(1, T, time, normbetadot, 2, &scale);
    
    for (j=0; j<T*n; j++)
        beta_scaled[j] = beta[j]/scale;
    
    mxFree(betadot);
    mxFree(normbetadot);
    mxFree(time);
    }


/* Directional derivative dF_I(M) */
void
dF_M(int mm, int mn, double *M, int n, int T, double *beta, double *dF) {
    int k, j, i;
    double step = 1.0/(double) T;
    double step2 = 1.0/((double) T - 1.0); /* maybe we don't need this */
    double *betadot = mxMalloc(n*T*sizeof(double)); /* n x T */
    double *normbetadot = mxMalloc(T*sizeof(double)); /* 1 x T */
    double *time = mxMalloc(T*sizeof(double)); /* 1 x T */
    
    double *integrand = mxMalloc(n*n*T*sizeof(double));
    double *integrand1 = mxMalloc(n*n*sizeof(double));
    double *integrand2 = mxMalloc(n*n*sizeof(double));
    double *a = mxMalloc(n*sizeof(double));
    
    /* extra storage for computing stuff */
    double *aa = mxMalloc(n*n*sizeof(double));
    double *bb = mxMalloc(n*n*sizeof(double));
    double *ab = mxMalloc(n*n*sizeof(double));
    double *ba = mxMalloc(n*n*sizeof(double));
    double *Mbdot = mxMalloc(n*sizeof(double));
    double bdotMbdot;
    
    /* form time vector */
    time[0] = 0;
    for (k=1; k<T; k++)
        time[k] = time[k-1]+step2;
    
    /* compute gradient */
    col_gradient(n, T, beta, step, betadot);
    
    /* compute norm of each column of betadot*/
    for (j=0; j<T; j++) {
        normbetadot[j] = 0;
        for (k=0; k<n; k++)
            normbetadot[j] += betadot[k+n*j]*betadot[k+n*j];
        normbetadot[j] = sqrt(normbetadot[j]);
        }
    
    calculateCentroid(n, T, beta, a);
    for (k=0; k<n; k++)
        a[k] = -a[k];
    /* form outer product of vector a */
    product(n, 1, n, a, a, aa);
    
    for (i=0; i<T; i++) {
        /* form outer product of beta(:,i) */
        product(n, 1, n, &beta[i*n], &beta[i*n], bb);
        
        /* form product a*b' */
        product(n, 1, n, a, &beta[i*n], ab);
        
        /* form product b*a' */
        product(n, 1, n, &beta[i*n], a, ba);
        
        /* form product bdot'*M*bdot */
        product(n, n, 1, M, &betadot[i*n], Mbdot);
        product(1, n, 1, &betadot[i*n], Mbdot, &bdotMbdot);
        
        /* zero out integrand1 */
        for (k=0; k<n*n; k++)
            integrand1[k] = 0;
        
        /* M*(b*b') */
        product_sum(n, n, n, M, bb, integrand1);
        /* (b*b')*M */
        product_sum(n, n, n, bb, M, integrand1);
        /* M*(b*a') */
        product_sum(n, n, n, M, ba, integrand1);
        /* a*b'*M */
        product_sum(n, n, n, ab, M, integrand1);
        
        for (k=0; k<n*n; k++) {
            integrand1[k] += aa[k];
            integrand1[k] *= normbetadot[i];
            }
        
        /* 2*bdot'*M*bdot*(b*b'+b*a'+a*b'+a*a')/(2*normbetadot) */
        for (k=0; k<n*n; k++) {
            integrand2[k] = bb[k]+ba[k]+ab[k]+aa[k];
            integrand2[k] *= 2*bdotMbdot;
            integrand2[k] /= (2*normbetadot[i]);
            }
        
        for (k=0; k<n*n; k++)
            integrand[k+i*n*n] = integrand1[k] + integrand2[k];
        }
    
    trapz3(n, n, T, time, integrand, dF);
    
    /* clean up */
    mxFree(betadot); mxFree(normbetadot); mxFree(time);
    mxFree(integrand); mxFree(integrand1); mxFree(integrand2);
    mxFree(a); mxFree(aa); mxFree(bb); mxFree(ab);
    mxFree(ba); mxFree(Mbdot);
    }


void
FA(int am, int an, double *A, int n, int T, double *beta, double *F) {
    /* A - [am x an]
     * beta - [n x T]
     * F - [n x n]
     */
    int k, j, i;
    double step = 1.0/(double) T;
    double step2 = 1.0/((double) T - 1.0);
    double *Abeta = mxMalloc(n*T*sizeof(double)); /* n x T */
    double *Abetadot = mxMalloc(n*T*sizeof(double)); /* n x T */
    double *normAbetadot = mxMalloc(T*sizeof(double)); /* 1 x T */
    double *time = mxMalloc(T*sizeof(double)); /* 1 x T */
    double *integrand = mxMalloc(n*n*T*sizeof(double)); /* n x n x T */
    double *a = mxMalloc(n*sizeof(double)); /* n x 1 */
    double *Ab = mxMalloc(n*sizeof(double)); /* n x 1 */
    
    /* form time vector */
    time[0] = 0;
    for (k=1; k<T; k++)
        time[k] = time[k-1]+step2;
    
    /* compute A*beta */
    product(n, n, T, A, beta, Abeta);
    
    /* compute gradient of Abeta */
    col_gradient(n, T, Abeta, step, Abetadot);
    
    /* compute centroid of Abeta */
    calculateCentroid(n, T, Abeta, a);
    for (k=0; k<n; k++)
        a[k] = -a[k];
    
    /* compute norm of each column of Abetadot*/
    for (j=0; j<T; j++) {
        normAbetadot[j] = 0;
        for (k=0; k<n; k++)
            normAbetadot[j] += Abetadot[k+n*j]*Abetadot[k+n*j];
        normAbetadot[j] = sqrt(normAbetadot[j]);
        }
    
    for (i=0; i<T; i++) {
        /* Ab = A*b */
        product(n, n, 1, A, &beta[i*n], Ab);
        
        /* Ab = Ab+a */
        for (k=0; k<n; k++)
            Ab[k] += a[k];
        
        /* integrand[:,:,i] = (A*b+a)*(A*b+a)'*normAbetadot; */
        product(n, 1, n, Ab, Ab, &integrand[i*n*n]);
        for (k=0; k<n*n; k++)
            integrand[k+i*n*n] *= normAbetadot[i];
        }
    
    trapz3(n, n, T, time, integrand, F);
    
    /* clean up */
    mxFree(Abeta); mxFree(Abetadot); mxFree(normAbetadot);
    mxFree(time); mxFree(integrand); mxFree(a); mxFree(Ab);
    }


void
ReSampleCurve(int n, int T, double *X, int N, double *Xn) {
    /* X - [n x T]
     * Xn - [n x N]
     */
    int k, j;
    double *del = mxMalloc(T*sizeof(double));
    double *newdel = mxMalloc(N*sizeof(double));
    double *Xk = mxMalloc(T*sizeof(double));
    double *Yi = mxMalloc(N*sizeof(double));
    double *C = mxMalloc(T*sizeof(double));
    double step = 1.0/((double) N - 1.0);
    double scale;
    
    del[0] = 0;
    for (j=1; j<T; j++) {
        del[j] = 0;
        for (k=0; k<n; k++)
            del[j] += (X[k+j*n] - X[k+(j-1)*n])*(X[k+j*n] - X[k+(j-1)*n]);
        del[j] = del[j-1]+sqrt(del[j]);
        }
    scale = del[T-1];
    for (j=1; j<T; j++)
        del[j] /= scale;
    
    /* make time vector */
    newdel[0] = 0;
    for (k=1; k<N; k++)
        newdel[k] = newdel[k-1]+step;
    
    /* interpolate to get new values */
    for (k=0; k<n; k++) {
        /* copy values into tmp storage */
        for (j=0; j<T; j++)
            Xk[j] = X[k+j*n];
        
        spline_coef(del, Xk, T, C);
        spline_eval(del, Xk, C, T, newdel, Yi, N);
        
        for (j=0; j<N; j++)
            Xn[k+j*n] = Yi[j];
        }
    
    /* clean up */
    mxFree(del); mxFree(newdel); mxFree(Xk); mxFree(Yi); mxFree(C);
    }


/* Algorithm to transform a curve beta to have centroid 0 and covariance 
 * matrix Cov. */
void
destandardizeCurve(int n, int T, double *beta, double *Cov, 
                   double *betaDestandardized, double *Atot) {
    int k, j;
    double *centroid = mxMalloc(n*sizeof(double));
    
    /* Basis for tangent space of symmetric matrices */
    double B1[4] = {1, 0, 0, 0}; /* [1,0;0,0] */
    double B2[4] = {0, 1, 1, 0}; /* [0,1;1,0] */
    double B3[4] = {0, 0, 0, 1}; /* [0,0;0,1] */
    
    int maxit = 200;
    int iter = 0;
    double tol = 10^-7;
    double delta = 0.001;
    double variance_old[4] = {0, 0, 0, 0}; /* 2 x 2 */
    double variance_new[4] = {1, 0, 0, 1}; /* eye(2) */
    /*double Atot[4] = {1, 0, 0, 1}; /* eye(2) */
    double I[4] = {1, 0, 0, 1}; /* eye(2) */
    double normVarDiff;
    
    double dFI_B1[4];
    double dFI_B2[4];
    double dFI_B3[4];
    double dFI[9];
    double FI[4];
    double FIv[3];
    double A[4];
    double V[3];
    
    /* compute centroid of beta */
    calculateCentroid(n, T, beta, centroid);
    
    /* normalize beta */
    for (k=0; k<n; k++)
        for (j=0; j<T; j++)
            beta[k+j*n] -= centroid[k];
    scale_curve(n, T, beta, beta);
    
    do {
        /* save old variance */
        for (k=0; k<n*n; k++)
            variance_old[k] = variance_new[k];
        
        dF_M(2, 2, &B1[0], n, T, beta, &dFI_B1[0]);
        dF_M(2, 2, &B2[0], n, T, beta, &dFI_B2[0]);
        dF_M(2, 2, &B3[0], n, T, beta, &dFI_B3[0]);
        
        /* make dFI */
        dFI[0] = dFI_B1[0]; dFI[1] = dFI_B1[2]; dFI[2] = dFI_B1[3];
        dFI[3] = dFI_B2[0]; dFI[4] = dFI_B2[2]; dFI[5] = dFI_B2[3];
        dFI[6] = dFI_B3[0]; dFI[7] = dFI_B3[2]; dFI[8] = dFI_B3[3];
        
        FA(2, 2, &I[0], n, T, beta, &FI[0]);
        for (k=0; k<4; k++)
            FI[k] -= Cov[k];
        FIv[0] = FI[0]; FIv[1] = FI[2]; FIv[2] = FI[3];
        
        /* V=dFI\FIv; */
        inverse3_in(&dFI[0]);
        product(3, 3, 1, &dFI[0], &FIv[0], &V[0]);
        
        for (k=0; k<4; k++)
            A[k] = I[k] - delta*(V[1]*B1[k] + V[2]*B2[k] + V[3]*B3[k]);
        
        iter++;
        
        /* Update beta and Atot */
        product_in(n, T, A, beta);
        calculateCentroid(n, T, beta, centroid);
        for (k=0; k<n; k++)
            for (j=0; j<T; j++)
                beta[k+j*n] -= centroid[k];
        ReSampleCurve(n, T, beta, T, beta);
        scale_curve(n, T, beta, beta);
        calculateVariance(n, T, beta, variance_new);
        product_in(2, 2, A, Atot);
        
        /* compute variance norm (Frobenius)*/
        normVarDiff = 0;
        for (j=0; j<n*n; j++)
            normVarDiff += (variance_new[j]-variance_old[j])*(variance_new[j]-variance_old[j]);
        normVarDiff = sqrt(normVarDiff);
        } while ((iter<maxit) && (normVarDiff>tol));
    
    /* copy beta into return variable */
    for (k=0; k<n*T; k++)
        betaDestandardized[k] = beta[k];
    }