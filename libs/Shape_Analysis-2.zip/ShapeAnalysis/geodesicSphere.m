function [dist,pathq,pathbeta,O]=geodesicSphere(beta1,beta2,k)

% Load some parameters
lam = 0;
[n,T]=size(beta1);
% T=100;

% What displays you want to see
Disp_geodesic_between_the_curves = 1;
Disp_registration_between_curves = 1;

% Calculate distance modulo SO(2) and/or Gamma
elastic=1;
rotation=1;
returnPath=1;

% beta1 = ReSampleCurve(beta1,T);
% beta2 = ReSampleCurve(beta2,T);

centroid1=calculateCentroid(beta1);
beta1=beta1-repmat(centroid1,1,T);
centroid2=calculateCentroid(beta2);
beta2=beta2-repmat(centroid2,1,T);

q1=curve_to_q(beta1);

if rotation
    [beta2,O1]=Find_Rotation_and_Seed_Coord(beta1,beta2);
    q2=curve_to_q(beta2);
else
    O1=eye(2);
    q2=curve_to_q(beta2);
end

if elastic
    % Find the optimal coorespondence
    gam = DynamicProgrammingQ(q1,q2,lam,1);
    gamI = invertGamma(gam);
    gamI = (gamI-gamI(1))/(gamI(end)-gamI(1));

    % Applying optimal re-parameterization to the second curve
    beta2n = Group_Action_by_Gamma_Coord(beta2,gamI);
    q2n=curve_to_q(beta2n);
   
    if rotation
        % Find Optimal Rotation and seed location of q2
        [beta2n,O2]=Find_Rotation_and_Seed_Coord(beta1,beta2n);
        centroid2=calculateCentroid(beta2n);
        beta2n=beta2n-repmat(centroid2,1,T);
        q2n=curve_to_q(beta2n);
        O=O1*O2;
    end
else
    q2n=q2;
    O=O1;
end

% Forming geodesic between the registered curves
dist = acos(InnerProd_Q(q1,q2n));
if returnPath
    PsiQ=zeros(n,T,k);
    PsiX=PsiQ;
    for tau=1:k
        s = dist*(tau-1)/(k-1);
        PsiQ(:,:,tau) = (sin(dist - s)*q1 + sin(s)*q2n)/sin(dist);
        PsiX(:,:,tau) = q_to_curve(PsiQ(:,:,tau));
    end
    pathq=PsiQ;
    pathbeta = PsiX;
else
    path=0;
end
%sprintf('The distance between the two curves is %0.3f',dist)

% Displaying the correspondence
if(Disp_registration_between_curves)
    
    beta1=beta1-repmat(calculateCentroid(beta1),1,T);
    beta2n=beta2n-repmat(calculateCentroid(beta2n),1,T);
    beta2n(1,:)=beta2n(1,:)+1.3;
    beta2n(2,:)=beta2n(2,:)-0.1;
    figure; hold on;
    plot(beta1(1,:), beta1(2,:),'r','LineWidth',3); axis equal off;
    plot(beta2n(1,:), beta2n(2,:),'b-o','LineWidth',3);
    for j=1:T/5
        i = j*5;
        plot([beta1(1,i) beta2n(1,i)],[beta1(2,i) beta2n(2,i)],'k','LineWidth',2);
    end
end

% Displaying the geodesic
colorc = {'b','m','k','g','r','b','k'};
linewidthl = [5,3,3,3,3,3,5];
if(Disp_geodesic_between_the_curves)
    figure; hold on;
    for tau=1:k
        if n==2
            PsiX(:,end+1,tau) = PsiX(:,end,tau);
            plot(.30*tau+PsiX(1,:,tau), PsiX(2,:,tau),'m','LineWidth',linewidthl(tau)); 
            axis equal off;
        elseif n==3
            plot3(.35*tau+PsiX(1,:,tau), PsiX(2,:,tau), PsiX(3,:,tau),'k','LineWidth',2); 
            axis equal off;
        end
    end
end