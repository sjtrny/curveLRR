#include "mex.h"
#include <math.h>
#include "destdCurve.c"

void mexFunction(int nlhs, mxArray **plhs, int nrhs, const mxArray **prhs) {
    int n, T;
    double *beta, *beta_scaled;
    
    /* Get input information */
    beta = mxGetPr(prhs[0]);
    n = mxGetM(prhs[0]);
    T = mxGetN(prhs[0]);
    
    /* Allocate storage for output */
    plhs[0] = mxCreateDoubleMatrix(n, T, mxREAL);
    beta_scaled = mxGetPr(plhs[0]);
    
    scale_curve(n, T, beta, beta_scaled);
    }