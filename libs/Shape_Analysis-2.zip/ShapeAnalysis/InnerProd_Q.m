function val = InnerProd_Q(q1,q2)

[~,T] = size(q1);
val=sum(sum(q1.*q2))/T;