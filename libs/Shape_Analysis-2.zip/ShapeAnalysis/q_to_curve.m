function beta = q_to_curve(q)

[~,T] = size(q);
qnorm=zeros(1,T);
for i = 1:T
    qnorm(i)=norm(q(:,i));
end
integrand=[q(1,:).*qnorm; q(2,:).*qnorm];
beta=cumtrapz(integrand,2)/T;