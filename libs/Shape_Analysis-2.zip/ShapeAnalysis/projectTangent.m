function wproj = projectTangent(w,q,basis,str)

w=w-InnerProd_Q(w,q)*q;
bo = gramSchmidt(basis,str);

if str=='A'
    wproj=w-InnerProd_Q(w,bo{1})*bo{1}-InnerProd_Q(w,bo{2})*bo{2}-...
        InnerProd_Q(w,bo{3})*bo{3}-InnerProd_Q(w,bo{4})*bo{4};
elseif str=='C'
    wproj=w-InnerProd_Q(w,bo{1})*bo{1}-InnerProd_Q(w,bo{2})*bo{2};
end
