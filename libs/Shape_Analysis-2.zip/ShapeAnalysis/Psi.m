function [Psi1,Psi2,Psi3,Psi4] = Psi(x,a,q)

T=length(q);
% for i=1:T
%     integrand1(i)=q(:,i)'*q(:,i)*((a(1)+x(1,i))^2-(a(2)+x(2,i))^2);
%     integrand2(i)=q(:,i)'*q(:,i)*((a(1)+x(1,i))*(a(2)+x(2,i)));
% end
% Psi1=trapz(linspace(0,1,T),integrand1);
% Psi2=trapz(linspace(0,1,T),integrand2);

% for i=1:T
%     integrand1alt(i)=q(:,i)'*q(:,i)*(x(1,i)^2-x(2,i)^2);
%     integrand2alt(i)=q(:,i)'*q(:,i)*(x(1,i)*x(2,i));
% end
% Psi1=a(2)^2-a(1)^2+trapz(linspace(0,1,T),integrand1alt);
% Psi2=-a(1)*a(2)+trapz(linspace(0,1,T),integrand2alt);

CovMat=calculateVariance(x+repmat(a,1,T));
Psi1=CovMat(1,1)-CovMat(2,2);
Psi2=CovMat(1,2);
Psi3=x(1,end);
Psi4=x(2,end);