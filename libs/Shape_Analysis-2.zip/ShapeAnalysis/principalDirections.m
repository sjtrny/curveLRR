function Data = principalDirections(betamean,mu,K,params)
% Plots the principal direction of variation specified by dir=1:3. N is 
% Number of shapes away from mean. Creates 2*N+1 shape sequence

N=params.N;
str=params.str;
T=params.T;
m=params.m;

[U,S,V]=svd(K);

for dir=1:m

    princDir=[U(1:T,dir)';U(T+1:2*T,dir)'];
    v=sqrt(S(dir,dir))*princDir; 
    q1=mu;
    epsilon=2/N; 

    % Forward direction from mean
    for i=1:N
        normv=sqrt(InnerProd_Q(v,v));

        %q=exp_mu(v)
        if normv<10^-4
            q2=mu;
        else
            q2=cos(epsilon*normv)*q1+sin(epsilon*normv)*v/normv;
            if (str=='A') || (str=='C')
                q2=projectCurve(q2,str);
            end
        end

        qarray1{i}=q2;
        p=q_to_curve(qarray1{i});
        Data1{i}=scale_curve(p-repmat(calculateCentroid(p),1,T));

        % Parallel translate tangent vector
        basis2=findBasisNormal(q2,str);
        v = parallelTranslate(v,q1,q2,basis2,str);

        q1=q2;
    end

    % Backward direction from mean
    v=-sqrt(S(dir,dir))*princDir;
    q1=mu;
    for i=1:N
        normv=sqrt(InnerProd_Q(v,v));

        %q=exp_mu(v)
        if normv<10^-4
            q2=mu;
        else
            q2=cos(epsilon*normv)*q1+sin(epsilon*normv)*v/normv;
            if (str=='A') || (str=='C')
                q2=projectCurve(q2,str);
            end
        end

        qarray2{i}=q2;
        p=q_to_curve(qarray2{i});
        Data2{i}=scale_curve(p-repmat(calculateCentroid(p),1,T));

        % Parallel translate tangent vector
        basis2=findBasisNormal(q2,str);
        v = parallelTranslate(v,q1,q2,basis2,str);

        q1=q2;
    end

    for i=1:N
        qarray{dir,i}=qarray2{N-(i-1)};
        Data{dir,i}=Data2{N-(i-1)};
    end
    qarray{dir,N+1}=mu;
    Data{dir,N+1}=scale_curve(betamean-repmat(calculateCentroid(betamean),1,T));
    for i=N+2:2*N+1
        qarray{dir,i}=qarray1{i-(N+1)};
        Data{dir,i}=Data1{i-(N+1)};
    end

%     % Plot path
%     figure(12); axis equal off; hold on;
%     k=2*N+1;
%     for tau=1:k
%         plot( 0.33*tau+Data{tau}(1,:), -0.5*dir+Data{tau}(2,:),'k','LineWidth',3); 
%     end

end