function J = calculateJ(basis,str)

if str=='C'
    
    b1=basis{1};
    b2=basis{2};
    T=length(b1);
    integrand11=zeros(1,T);
    integrand12=zeros(1,T);
    integrand22=zeros(1,T);
  
    for i=1:T
        integrand11(i)=b1(:,i)'*b1(:,i);
        integrand12(i)=b1(:,i)'*b2(:,i);
        integrand22(i)=b2(:,i)'*b2(:,i);
    end
 
    J(1,1)=trapz(linspace(0,1,T),integrand11);
    J(1,2)=trapz(linspace(0,1,T),integrand12);
    J(2,2)=trapz(linspace(0,1,T),integrand22);
    J(2,1)=J(1,2);
    
elseif str=='A'
    
    b1=basis{1};
    b2=basis{2};
    b3=basis{3};
    b4=basis{4};
    T=length(b1);
    integrand11=zeros(1,T);
    integrand12=zeros(1,T);
    integrand13=zeros(1,T);
    integrand14=zeros(1,T);
    integrand22=zeros(1,T);
    integrand23=zeros(1,T);
    integrand24=zeros(1,T);
    integrand33=zeros(1,T);
    integrand34=zeros(1,T);
    integrand44=zeros(1,T);
    
    for i=1:T
        integrand11(i)=b1(:,i)'*b1(:,i);
        integrand12(i)=b1(:,i)'*b2(:,i);
        integrand13(i)=b1(:,i)'*b3(:,i);
        integrand14(i)=b1(:,i)'*b4(:,i);
        integrand22(i)=b2(:,i)'*b2(:,i);
        integrand23(i)=b2(:,i)'*b3(:,i);
        integrand24(i)=b2(:,i)'*b4(:,i);
        integrand33(i)=b3(:,i)'*b3(:,i);
        integrand34(i)=b3(:,i)'*b4(:,i);
        integrand44(i)=b4(:,i)'*b4(:,i);
    end
    
    J(1,1)=trapz(linspace(0,1,T),integrand11);
    J(1,2)=trapz(linspace(0,1,T),integrand12);
    J(1,3)=trapz(linspace(0,1,T),integrand13);
    J(1,4)=trapz(linspace(0,1,T),integrand14);
    J(2,2)=trapz(linspace(0,1,T),integrand22);
    J(2,3)=trapz(linspace(0,1,T),integrand23);
    J(2,4)=trapz(linspace(0,1,T),integrand24);
    J(3,3)=trapz(linspace(0,1,T),integrand33);
    J(3,4)=trapz(linspace(0,1,T),integrand34);
    J(4,4)=trapz(linspace(0,1,T),integrand44);
    J(2,1)=J(1,2);
    J(3,1)=J(1,3);
    J(4,1)=J(1,4);
    J(3,2)=J(2,3);
    J(4,2)=J(2,4);
    J(4,3)=J(3,4);
   
end