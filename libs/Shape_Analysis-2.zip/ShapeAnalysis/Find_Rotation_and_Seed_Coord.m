function [beta2new,O_hat,tau] = Find_Rotation_and_Seed_Coord(beta1,beta2)
% This function returns a candidate list of optimally oriented and
% registered (seed) shapes w.r.t. beta1

T = length(beta1);
q1=curve_to_q(beta1);
Ltwo=zeros(1,T);
Rlist{1,T}=[];
for ctr = 0:T-1
    beta2n = ShiftF(beta2,ctr);
    [beta2new,R] = Find_Best_Rotation(beta1,beta2n);
    q2new=curve_to_q(beta2new);
    Ltwo(ctr+1) = InnerProd_Q(q1 - q2new,q1 - q2new);
    Rlist{ctr+1} = R;
end
[~,Ltwo_idx] = min(Ltwo);
tau=Ltwo_idx-1;
O_hat = Rlist{Ltwo_idx};
clear beta2new;
beta2new = ShiftF(beta2,tau);
beta2new = O_hat*beta2new;


