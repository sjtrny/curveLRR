
function Xn = ReSampleCurve(X,N)

[n,T]=size(X);
del=zeros(1,T);
del(1)=0;
for r = 2:T
    del(r) = norm(X(:,r) - X(:,r-1));
end
cumdel = cumsum(del)/sum(del);   

newdel = linspace(0,1,N);
%newdel=[1:N]/N;  
Xn=zeros(n,N);
for i=1:n
    Xn(i,:) = spline(cumdel,X(i,:),newdel);
end