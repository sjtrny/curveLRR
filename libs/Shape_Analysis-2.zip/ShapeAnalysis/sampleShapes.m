function samples = sampleShapes(mu,K,params)

numSamples=params.numSamples;
str=params.str;
m=params.m;
T=params.T;

[U,S,V]=svd(K);

%Number shapes in calculating exp mapping
if str=='O'
    N=2;
else
    N=10; 
end
epsilon=1/(N-1);

for i=1:numSamples
    v=zeros(2,T);
    for dir=1:m
        v=v+randn*sqrt(S(dir,dir))*[U(1:T,dir)';U(T+1:2*T,dir)'];
    end
    
    %q=exp_mu(v) using N steps
    q1=mu;
    for j=1:N-1
        normv=sqrt(InnerProd_Q(v,v));
        
        if normv<10^-4
            q2=mu;
        else
            q2=cos(epsilon*normv)*q1+sin(epsilon*normv)*v/normv;
            if (str=='A') || (str=='C')
                q2=projectCurve(q2,str);
            end
        end

        % Parallel translate tangent vector
        basis2=findBasisNormal(q2,str);
        v = parallelTranslate(v,q1,q2,basis2,str);

        q1=q2;
    end
    samples{i}=q_to_curve(q2);
end

% plotCurves(samples,2);
