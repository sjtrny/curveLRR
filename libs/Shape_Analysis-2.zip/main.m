clear all;
close all;
path(path,'./ShapeAnalysis');
path(path,'./Data');

% load data
load 4.mat;
beta1 = C;
load 12.mat;
beta2 = C;

% plot figure
figure(1),plotR2(beta1,'r');
figure(2),plotR2(beta2,'b');

%geodesic
[dist,path,O]=geodesicSphere(beta1,beta2,7);


%% Examples of Calculating Karcher mean
load Fish_test_data
data = Fish_test_data;
[Ndata,~,~]= size(Fish_test_data);
for i=1:Ndata
   xdata = squeeze(data(i,:,:));
   q1=curve_to_q(xdata);
   qdata{i} = q1;
   xxdata{i} = xdata;
end

[mu,betamean,v] = findKarcherMean(qdata,xxdata,'C');

% plot data, and plot mean;
figure(11); clf;
ha = tight_subplot(ceil(Ndata/8),8,0.01,0.03,0.03);
for m=1:Ndata
    cdata = xxdata{m};
    axes(ha(m));
    plot(cdata(1,:), cdata(2,:),'b','LineWidth',2);
    axis equal off;
end;

for m=Ndata+1:ceil(Ndata/8)*8
    axes(ha(m));
    axis equal off;
end;
figure(12);clf;
plotR2(betamean,'m'); 


%% Calculate Karcher variance;
K = computeKarcherCov(betamean,xxdata,'C');

% Show principal directions of variance 
[n,T]=size(beta1);
params.str = 'C';
params.T = T;
params.m = 3;
params.N = 7;
params.n = n;

Data_princ=principalDirections(betamean,mu,K,params);
figure(5); clf;
N = params.N;
m = 3;
k=0;
for i=1:m
    figure;clf;
    ha = tight_subplot(1,2*N+1,0.01,0.03,0.03);
    for j=1:2*N+1
        axes(ha(j))
        if(j==N+1)
            plotR2(Data_princ{i,j},'m');
        else
            plotR2(Data_princ{i,j},'b');
        end;
    end
end;



%% Create and show random samples
Nsamp = 20;
params.numSamples = Nsamp;
samples=sampleShapes(mu,K,params);
figure(6); clf;
ha = tight_subplot(4,5,0.01,0.03,0.03);
for i=1:Nsamp
    axes(ha(i))
    plotR2(samples{i},'b');
end




